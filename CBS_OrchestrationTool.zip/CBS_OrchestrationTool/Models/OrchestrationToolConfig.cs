﻿namespace CBS_OrchestrationTool
{
    internal class OrchestrationToolConfig
    {
        public string RuleAppName { get; set; }
        public int Revision { get; set; }
        public string EntityName { get; set; }
        public RESConfig ExecutionService { get; set; }
        public string EntityStateFile { get; set; }
        public int ItemsPerSubBatch { get; set; }
        public int MaxParallelRequests { get; set; }
        public int MachineCores { get; set; }
        public string Datasource { get; set; }
        public string Database { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int HouseHoldCountStart { get; set; }
        public int HouseHoldCountEnd { get; set; }
        public int Jaar { get; set; }
        public LowIncomeSQLTables LowIncomeSQLTables { get; set; }
        public bool DeleteOutputTables { get; set; }
        public string LogFileDirectory { get; set; }
    }
    internal class LowIncomeSQLTables
    {
        public string PersonTable { get; set; }
        public string HouseholdTable { get; set; }
        public string LinkTable { get; set; }
        public string HouseholdOutputTable { get; set; }
        public string PersonOutputTable { get; set; }
    }
    internal class RESConfig
    {
        public string ResUrl { get; set; }
        public string AuthHeader { get; set; }
        public string CatalogUrl { get; set; }
        public string CatalogUser { get; set; }
        public string CatalogPassword { get; set; }
    }
    internal class SQL_LowIncome
    {
        public string LowIncomeSQLInput { get; set; }
    }
}
