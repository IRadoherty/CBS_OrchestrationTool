﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBS_LoadTest_NF
{
    internal class BatchProcessingRequest
    {

        public BatchProcessingRequest()
        {
            Jaar = Jaar;
            Households = new List<Household>();
            Lock = new object();
        }


        public void Reset()
        {
            Households = new List<Household>();
        }
        internal object Lock; // Used because multi-threaded so that different execution request threads don't collide on the same List
        //public List<object> Households { get; set; }
        public List<Household> Households { get; set; }
        public int Jaar { get; set; }

    }
    internal class BatchRootEntity
    {
        public BatchRootEntity()
        {
            Households = new List<Household>();
        }
        public List<Household> Households { get; set; }
    }

    public class CBS_Inbound
    {
        public List<Household> Households { get; set; }
    }





    public class ExecutionService
    {
        public string ResUrl { get; set; }
        public string CatalogUrl { get; set; }
        public string CatalogUser { get; set; }
        public string CatalogPassword { get; set; }
    }

    public class Configs
    {
        public ExecutionService ExecutionService { get; set; }
        public string RuleAppName { get; set; }
        public string EntityName { get; set; }
        public string EntityStateFile { get; set; }
        public int ItemsPerSubBatch { get; set; }
        public int MaxParallelRequests { get; set; }
    }
    public class CBS_Payload
    {
        public int Jaar { get; set; }
        public List<Household> Households { get; set; }
    }
    public class CBS_EntitySate
    {
        public int Jaar { get; set; }
        public Household Households { get; set; }
    }
    public class CBS_Households
    {
        public Household Households { get; set; }
    }
    public class Household
    {
        public int I_HH_ID { get; set; }
        public double BESTINKH { get; set; }
        public double EQUI { get; set; }
        public string POP { get; set; }
        public double SAMHH { get; set; }
        public HouseholdHelperAttributes HouseholdHelperAttributes { get; set; }
        public HouseholdOutputAttributes HouseholdOutputAttributes { get; set; }
        public List<Person> Persons { get; set; }
    }
    public class Person
    {
        public double I_SOFINR { get; set; }
        public double I_HH_ID1 { get; set; }
        public double I_SOFINR1 { get; set; }
        public string PAARCOD { get; set; }
        public string POSHHK { get; set; }
        public string WEKEN { get; set; }
        public string BRUTOGRONDBOX3 { get; set; }
        public string YVBD3610 { get; set; }
        public string T07_OGO { get; set; }
        public double GEBJAAR { get; set; }
        public string WSFRECHT { get; set; }
        public string YBTL7370 { get; set; }
        public string YBTS7380 { get; set; }
        public string PERSINK { get; set; }
        public string T6330STU { get; set; }
        public string T6320KB { get; set; }
        public string T6325KGB { get; set; }
        public string PH865ZFW { get; set; }
        public string PH868ZTS { get; set; }
        public string YCGW5246 { get; set; }
        public string YCGW6346 { get; set; }
        public string YKKT6348 { get; set; }
        public string GEBMAAND { get; set; }
        public double SECJ { get; set; }
        public PersonHelperAttributes PersonHelperAttributes { get; set; }
        public PersonOutputAttributes PersonOutputAttributes { get; set; }
    }
    public class CBSArray
    {
        public List<Item> data;
    }
    public class Item
    {
        public int I_SOFINR { get; set; }
        public string PAAR_NR { get; set; }
        public string WEKEN { get; set; }
        public string BRUTOGRONDBOX3 { get; set; }
        public string YVBD3610 { get; set; }
        public string T07_OGO { get; set; }
        public double GEBJAAR { get; set; }
        public string WSFRECHT { get; set; }
        public string YBTL7370 { get; set; }
        public string YBTS7380 { get; set; }
        public string PERSINK { get; set; }
        public string T6330STU { get; set; }
        public string T6320KB { get; set; }
        public string T6325KGB { get; set; }
        public string PH865ZFW { get; set; }
        public string PH868ZTS { get; set; }
        public string YCGW5246 { get; set; }
        public string YCGW6346 { get; set; }
        public string YKKT6348 { get; set; }
        public string GEBMAAND { get; set; }
        public double SECJ { get; set; }
        public string POSHHK { get; set; }
        public int I_HH_ID { get; set; }
        public int BESTINKH { get; set; }
        public int EQUI { get; set; }
        public string POP { get; set; }
        public int SAMHH { get; set; }
    }
    public class HouseholdHelperAttributes
    {
        public double LIAANTD2 { get; set; }
        public double LI_TO7_OGO { get; set; }
        public bool PersonIsChildPupilStudentLivingOnOwn { get; set; }
        public bool PersonIsMemberOfCouple { get; set; }
        public double LFTM_ULTIMO { get; set; }
        public bool PersonReachedPensionableAgeAtEndOfStatisticalYear { get; set; }
        public bool PersonBelongsToThePopulation { get; set; }
        public double GEBJAARPART { get; set; }
        public double BMNORMP { get; set; }
    }

    public class HouseholdOutputAttributes
    {
        public int I_HH_ID { get; set; }
        public int LAAG_INK { get; set; }
        public int ARMLAG { get; set; }
        public int ARMLAGKL1 { get; set; }
        public int BMNORMH { get; set; }
        public int ARMSOC { get; set; }
        public int ARMSOCKL1 { get; set; }
    }
    public class PersonHelperAttributes
    {
        public bool PersonIsChildPupilStudentLivingOnOwn { get; set; }
        public bool PersonIsMemberOfCouple { get; set; }
        public double LFTM_ULTIMO { get; set; }
        public bool PersonReachedPensionableAgeAtEndOfStatisticalYear { get; set; }
        public bool PersonBelongsToThePopulation { get; set; }
        public double BMNORMP { get; set; }
    }

    public class PersonOutputAttributes
    {
        public double I_SOFINR { get; set; }
        public double BM_GROEP { get; set; }
        public double BMNORM { get; set; }
    }

    public class HouseholdOutput
    {
        public List<HouseholdOutputAttributes> HouseholdOutputAttributes { get; set; }
    }
    public class PersonOutput
    {
        public List<PersonOutputAttributes> PersonOutputAttributes { get; set; }
    }
    public class ParamatersCBS
    {
        public HouseholdOutput HouseholdOutput { get; set; }
        public PersonOutput PersonOutput { get; set; }
        public string result { get; set; }
    }

    public abstract class RuleRequest
    {
        public Ruleapp RuleApp { get; set; }
        public Ruleengineserviceoutputtypes RuleEngineServiceOutputTypes { get; set; }
        public abstract string Route { get; }
    }
    public abstract class EntityStateRuleRequest : RuleRequest
    {
        public string EntityName { get; set; }
        public string EntityState { get; set; }
    }
    public class Ruleapp
    {

        public string RepositoryServiceUri { get; set; }
        public Repositoryruleapprevisionspec RepositoryRuleAppRevisionSpec { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }
    }
    public class Repositoryruleapprevisionspec
    {

        public string RuleApplicationName { get; set; }
    }
    public class Ruleengineserviceoutputtypes
    {
        public bool ActiveNotifications { get; set; }
        public bool ActiveValidations { get; set; }
        public bool EntityState { get; set; }
        public bool Overrides { get; set; }
        public bool RuleExecutionLog { get; set; }
    }

    public class ApplyRulesRequest : EntityStateRuleRequest
    {
        public override string Route { get { return "ApplyRules"; } }
    }
    public class ExecuteRuleSetRequest : EntityStateRuleRequest
    {
        public override string Route { get { return "ExecuteRuleSet"; } }
        public Parameter[] Parameters { get; set; }
        public string RuleSetName { get; set; }
    }
    public class Parameter
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
    public class ExecuteDecisionRequest : RuleRequest
    {
        public override string Route { get { return "ExecuteDecision"; } }

        public string DecisionName { get; set; }
        public string InputState { get; set; }
    }

    public class ExecutionResponse
    {
        public Activenotification[] ActiveNotifications { get; set; }
        public Activevalidation[] ActiveValidations { get; set; }
        public bool HasRuntimeErrors { get; set; }
        public Ruleexecutionlog RuleExecutionLog { get; set; }
    }
    public class RuleExecutionResponse : ExecutionResponse
    {
        public string EntityState { get; set; }
    }
    public class DecisionExecutionResponse : ExecutionResponse
    {
        public string OutputState { get; set; }
    }
    public class Activenotification
    {
        public string ElementId { get; set; }
        public bool IsActive { get; set; }
        public string Message { get; set; }
        public string NotificationType { get; set; }
    }
    public class Activevalidation
    {
        public string ElementIdentifier { get; set; }
        public string InvalidMessageText { get; set; }
        public bool IsValid { get; set; }
        public Reason[] Reasons { get; set; }
    }
    public class Reason
    {
        public string FiringRuleId { get; set; }
        public string MessageText { get; set; }
    }
    public class Ruleexecutionlog
    {
        public Message[] Messages { get; set; }
        public long TotalEvaluationCycles { get; set; }
        public string TotalExecutionTime { get; set; }
        public int TotalTraceFrames { get; set; }
    }
    public class Message
    {
        public string Description { get; set; }
        public int ChangeType { get; set; }
        public int CollectionCount { get; set; }
        public string CollectionId { get; set; }
        public string MemberId { get; set; }
        public int MemberIndex { get; set; }
    }
}
