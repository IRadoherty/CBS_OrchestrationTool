﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBS_LoadTest_NF
{
    internal class BatchProcessingRequest
    {
        public BatchProcessingRequest()
        {
            Jaar = Jaar;
            Households = new List<Household>();
            Lock = new object();
        }
        public void Reset()
        {
            Households = new List<Household>();
        }
        internal object Lock; // Used because multi-threaded so that different execution request threads don't collide on the same List
        //public List<object> Households { get; set; }
        public List<Household> Households { get; set; }
        public int Jaar { get; set; }
    }

    public class ExecutionService
    {
        public string ResUrl { get; set; }
        public string CatalogUrl { get; set; }
        public string CatalogUser { get; set; }
        public string CatalogPassword { get; set; }
    }
    public class Household
    {
        public int? I_HH_ID { get; set; }
        public decimal? BESTINKH { get; set; }
        public decimal? EQUI { get; set; }
        public int? POP { get; set; }
        public int? SAMHH { get; set; }
        public HouseholdHelperAttributes HouseholdHelperAttributes { get; set; }
        public HouseholdOutputAttributes HouseholdOutputAttributes { get; set; }
        public List<Person> Persons { get; set; }
    }
    public class Person
    {
        public string I_SOFINR { get; set; }
        //public double I_HH_ID1 { get; set; }
        //public double I_SOFINR1 { get; set; }
        public int? PAARCOD { get; set; }
        public int? POSHHK { get; set; }
        public int? WEKEN { get; set; }
        public decimal? BRUTOGRONDBOX3 { get; set; }
        public decimal? YVBD3610 { get; set; }
        public decimal? T07_OGO { get; set; }
        public int? GEBJAAR { get; set; }
        public string WSFRECHT { get; set; }
        public decimal? YBTL7370 { get; set; }
        public decimal? YBTS7380 { get; set; }
        public decimal? PERSINK { get; set; }
        public decimal? T6330STU { get; set; }
        public decimal? T6320KB { get; set; }
        public decimal? T6325KGB { get; set; }
        public decimal? PH865ZFW { get; set; }
        public decimal? PH868ZTS { get; set; }
        public decimal? YCGW5246 { get; set; }
        public decimal? YCGW6346 { get; set; }
        public decimal? YKKT6348 { get; set; }
        public int? GEBMAAND { get; set; }
        public int? SECJ { get; set; }
        public PersonHelperAttributes PersonHelperAttributes { get; set; }
        public PersonOutputAttributes PersonOutputAttributes { get; set; }
    }


    public class HouseholdHelperAttributes
    {
        public decimal LIAANTD2 { get; set; }
        public decimal LI_TO7_OGO { get; set; }
        public bool PersonIsChildPupilStudentLivingOnOwn { get; set; }
        public bool PersonIsMemberOfCouple { get; set; }
        public decimal LFTM_ULTIMO { get; set; }
        public bool PersonReachedPensionableAgeAtEndOfStatisticalYear { get; set; }
        public bool PersonBelongsToThePopulation { get; set; }
        public decimal GEBJAARPART { get; set; }
        public decimal BMNORMP { get; set; }
    }

    public class HouseholdOutputAttributes
    {
        public int? I_HH_ID { get; set; }
        public int LAAG_INK { get; set; }
        public int ARMLAG { get; set; }
        public int ARMLAGKL1 { get; set; }
        public int BMNORMH { get; set; }
        public int ARMSOC { get; set; }
        public int ARMSOCKL1 { get; set; }
    }
    public class PersonHelperAttributes
    {
        public bool PersonIsChildPupilStudentLivingOnOwn { get; set; }
        public bool PersonIsMemberOfCouple { get; set; }
        public double LFTM_ULTIMO { get; set; }
        public bool PersonReachedPensionableAgeAtEndOfStatisticalYear { get; set; }
        public bool PersonBelongsToThePopulation { get; set; }
        public double BMNORMP { get; set; }
    }

    public class PersonOutputAttributes
    {
        public string I_SOFINR { get; set; }
        public double BM_GROEP { get; set; }
        public double BMNORM { get; set; }
    }

    public class HouseholdOutput
    {
        public List<HouseholdOutputAttributes> HouseholdOutputAttributes { get; set; }
    }
    public class PersonOutput
    {
        public List<PersonOutputAttributes> PersonOutputAttributes { get; set; }
    }
    //public class ParamatersCBS
    //{
    //    public HouseholdOutput HouseholdOutput { get; set; }
    //    public PersonOutput PersonOutput { get; set; }
    //    public string result { get; set; }
    //}

   
}
