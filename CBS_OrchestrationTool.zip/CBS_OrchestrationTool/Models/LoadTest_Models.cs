﻿namespace CBS_LoadTest_NF
{
    internal class LoadTestConfig
    {
        public string RuleAppName { get; set; }
        public int Revision { get; set; }
        public string EntityName { get; set; }
        public RESConfig ExecutionService { get; set; }
        public string EntityStateFile { get; set; }
        public int ItemsPerSubBatch { get; set; }
        public int MaxParallelRequests { get; set; }
        public string Datasource { get; set; }
        public string Database { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int HouseHoldCountStart { get; set; }
        public int HouseHoldCountEnd { get; set; }
    }
    internal class RESConfig
    {
        public string ResUrl { get; set; }
        public string AuthHeader { get; set; }
        public string CatalogUrl { get; set; }
        public string CatalogUser { get; set; }
        public string CatalogPassword { get; set; }
    }
}
