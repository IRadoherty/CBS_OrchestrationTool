﻿using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;
using System.Reflection;
using System.IO;
using System.Threading;
using System.Collections.Specialized;
using System.Text;

namespace CBS_OrchestrationTool
{
    class Program
    {
        private static int _executionId = 0;
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder().AddJsonFile($"appSettings.json", true, true);
            var builtConfig = builder.Build();
            var config = builtConfig.Get<OrchestrationToolConfig>();
            RexClient._config = config.ExecutionService;
            var Program = new Program();

            var DateTimeNowSTR = DateTime.Now.ToString().Replace("/", "").Replace(" ", "").Replace("A", "").Replace("M", "").Replace("P", "").Replace(":", "");
            var logFileName = config.LogFileDirectory + DateTimeNowSTR + ".txt";
            File.WriteAllText(logFileName, "CBS Orchestration Tool Log");
            Program.MainAsync(config, logFileName);
            Console.ReadLine();
        }

        private async void MainAsync(OrchestrationToolConfig config, string logFileName)
        {
            var startTimeOverall = DateTime.UtcNow;
            Output(logFileName, $"");
            Output(logFileName, $"Current configurations:");
            Output(logFileName, $"Rule application: {config.RuleAppName}");
            Output(logFileName, $"Items per subbatch: {config.ItemsPerSubBatch}");
            Output(logFileName, $"Max parallel requests: {config.MaxParallelRequests}");
            Output(logFileName, $"MachineCores: {config.MachineCores}");
            Output(logFileName, $"HouseHold count for each run: {config.HouseHoldCountEnd}");
            Output(logFileName, $"Beginning main run at {DateTime.Now}");
            int runCount = 1; // set initial run count

            try
            {
                string connString = @"Data Source=" + config.Datasource + ";Initial Catalog=" + config.Database + ";Persist Security Info=True;User ID=" + config.Username + ";Password=" + config.Password + ";MultipleActiveResultSets = true";
                int rowStart = config.HouseHoldCountStart; // HouseHold count start
                int rowPullCount = config.HouseHoldCountEnd; // HouseHold count end
                int rowEnd = rowPullCount;
                int householdTotal = 0;
                if (config.DeleteOutputTables == true)
                {
                    string deleteHouseHoldOutput = $"DELETE FROM {config.Database}.{config.LowIncomeSQLTables.HouseholdOutputTable}";
                    string deletePersonsOutput = $"DELETE FROM {config.Database}.{config.LowIncomeSQLTables.PersonOutputTable}";
                    using (SqlConnection connection = new SqlConnection(connString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(deleteHouseHoldOutput, connection))
                        using (SqlDataReader reader = command.ExecuteReader()) { }
                        using (SqlCommand command = new SqlCommand(deletePersonsOutput, connection))
                        using (SqlDataReader reader = command.ExecuteReader()) { }
                    }
                }
                bool cont = true; // Sets warm up calls to run only once for irServer
                int datatableCount = 0;
                int datatableCountM1 = 0;
                while (cont == true)
                {
                    var startTime = DateTime.UtcNow;
                    BatchProcessingRequest fullEntityStateObj = new BatchProcessingRequest()
                    {
                        Households = new List<Household>()
                    };
                    var startTimeSQLPull = DateTime.UtcNow;

                    using (SqlConnection connection = new SqlConnection(connString))
                    {
                        connection.Open();
                        Output(logFileName, $"Connecting to database and pulling data for run {runCount} for households between {rowStart} and {rowEnd}.");
                        string queryString = $"SELECT {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID, {config.LowIncomeSQLTables.PersonTable}.I_SOFINR, {config.LowIncomeSQLTables.LinkTable}.PAAR_NR, {config.LowIncomeSQLTables.PersonTable}.WEKEN, {config.LowIncomeSQLTables.PersonTable}.BRUTOGRONDBOX3, {config.LowIncomeSQLTables.PersonTable}.YVBD3610, {config.LowIncomeSQLTables.PersonTable}.T07_OGO, {config.LowIncomeSQLTables.PersonTable}.GEBJAAR, {config.LowIncomeSQLTables.PersonTable}.WSFRECHT, {config.LowIncomeSQLTables.PersonTable}.YBTL7370, {config.LowIncomeSQLTables.PersonTable}.YBTS7380, {config.LowIncomeSQLTables.PersonTable}.PERSINK, {config.LowIncomeSQLTables.PersonTable}.T6330STU, {config.LowIncomeSQLTables.PersonTable}.T6320KB, {config.LowIncomeSQLTables.PersonTable}.T6325KGB, {config.LowIncomeSQLTables.PersonTable}.PH865ZFW, {config.LowIncomeSQLTables.PersonTable}.PH868ZTS, {config.LowIncomeSQLTables.PersonTable}.YCGW5246, {config.LowIncomeSQLTables.PersonTable}.YCGW6346, {config.LowIncomeSQLTables.PersonTable}.YKKT6348, {config.LowIncomeSQLTables.PersonTable}.GEBMAAND, {config.LowIncomeSQLTables.PersonTable}.SECJ, {config.LowIncomeSQLTables.PersonTable}.POSHHK, {config.LowIncomeSQLTables.HouseholdTable}.BESTINKH, {config.LowIncomeSQLTables.HouseholdTable}.EQUI, {config.LowIncomeSQLTables.HouseholdTable}.POP, {config.LowIncomeSQLTables.HouseholdTable}.SAMHH FROM {config.LowIncomeSQLTables.HouseholdTable} INNER JOIN {config.LowIncomeSQLTables.LinkTable} ON {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID = {config.LowIncomeSQLTables.LinkTable}.I_HH_ID INNER JOIN {config.LowIncomeSQLTables.PersonTable} ON {config.LowIncomeSQLTables.LinkTable}.I_SOFINR = {config.LowIncomeSQLTables.PersonTable}.I_SOFINR where {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID BETWEEN {rowStart} and {rowEnd} ORDER by {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID ASC;";
                        using (SqlCommand command = new SqlCommand(queryString, connection))
                        {
                            var dataTable = new DataTable();
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                dataTable.Load(reader);
                                Output(logFileName, $"SQL pull completed in {Math.Round((DateTime.UtcNow - startTimeSQLPull).TotalSeconds, 3)} seconds.");

                                var startTimeDBMapping = DateTime.UtcNow;
                                datatableCount = dataTable.Rows.Count;
                                datatableCountM1 = datatableCount - 1;
                                Household household = null;
                                Person person = null;
                                bool pcont = true;
                                for (int g = 0; g < datatableCount; g++)
                                {
                                    household = new Household
                                    {
                                        I_HH_ID = dataTable.Rows[g].Field<int?>("I_HH_ID"),
                                        BESTINKH = dataTable.Rows[g].Field<decimal?>("BESTINKH"),
                                        EQUI = dataTable.Rows[g].Field<decimal?>("EQUI"),
                                        POP = dataTable.Rows[g].Field<int?>("POP"),
                                        SAMHH = dataTable.Rows[g].Field<int?>("SAMHH"),
                                        Persons = new List<Person>()
                                    };
                                    while (pcont == true)
                                    {
                                        person = new Person
                                        {
                                            I_SOFINR = dataTable.Rows[g].Field<string>("I_SOFINR"),
                                            POSHHK = dataTable.Rows[g].Field<int?>("POSHHK"),
                                            WEKEN = dataTable.Rows[g].Field<int?>("WEKEN"),
                                            BRUTOGRONDBOX3 = dataTable.Rows[g].Field<decimal?>("BRUTOGRONDBOX3"),
                                            YVBD3610 = dataTable.Rows[g].Field<decimal?>("YVBD3610"),
                                            T07_OGO = dataTable.Rows[g].Field<decimal?>("T07_OGO"),
                                            GEBJAAR = dataTable.Rows[g].Field<int?>("GEBJAAR"),
                                            WSFRECHT = dataTable.Rows[g].Field<string>("WSFRECHT"),
                                            YBTL7370 = dataTable.Rows[g].Field<decimal?>("YBTL7370"),
                                            YBTS7380 = dataTable.Rows[g].Field<decimal?>("YBTS7380"),
                                            PERSINK = dataTable.Rows[g].Field<decimal?>("PERSINK"),
                                            T6330STU = dataTable.Rows[g].Field<decimal?>("T6330STU"),
                                            T6320KB = dataTable.Rows[g].Field<decimal?>("T6320KB"),
                                            T6325KGB = dataTable.Rows[g].Field<decimal?>("T6325KGB"),
                                            PH865ZFW = dataTable.Rows[g].Field<decimal?>("PH865ZFW"),
                                            PH868ZTS = dataTable.Rows[g].Field<decimal?>("PH868ZTS"),
                                            YCGW5246 = dataTable.Rows[g].Field<decimal?>("YCGW5246"),
                                            YCGW6346 = dataTable.Rows[g].Field<decimal?>("YCGW6346"),
                                            YKKT6348 = dataTable.Rows[g].Field<decimal?>("YKKT6348"),
                                            GEBMAAND = dataTable.Rows[g].Field<int?>("GEBMAAND"),
                                            SECJ = dataTable.Rows[g].Field<int?>("SECJ"),
                                            PAARCOD = dataTable.Rows[g].Field<int?>("PAAR_NR")
                                        };
                                        household.Persons.Add(person);
                                        if (g != datatableCountM1)
                                        {
                                            if (household.I_HH_ID == dataTable.Rows[g + 1].Field<int?>("I_HH_ID")) { g++; }
                                            else { break; }
                                        }
                                        else { break; }
                                    };
                                    fullEntityStateObj.Households.Add(household);
                                }
                                Output(logFileName, $"Mapping complete for {datatableCount} persons/rows in {Math.Round((DateTime.UtcNow - startTimeDBMapping).TotalSeconds, 3)} seconds.");
                            }
                        }
                    }

                    rowStart = rowEnd + 1;
                    rowEnd += rowPullCount;
                    
                    householdTotal += fullEntityStateObj.Households.Count;

                    if (!fullEntityStateObj.Households.Any())
                    {
                        Output(logFileName, $"{householdTotal} households persons were processed in {Math.Round((DateTime.UtcNow - startTimeOverall).TotalMinutes, 3)} minutes at {DateTime.Now}");
                        cont = false;
                        return;
                    }
                    // Load all the sub-batches into the queue
                    var subBatches = new Queue<List<Household>>();
                    var subBatch = new List<Household>();
                    foreach (var item in fullEntityStateObj.Households)
                    {
                        subBatch.Add(item);
                        if (subBatch.Count >= config.ItemsPerSubBatch)
                        {
                            subBatches.Enqueue(subBatch);
                            subBatch = new List<Household>();
                        }
                    }
                    if (subBatch.Any())
                        subBatches.Enqueue(subBatch);
                    Output(logFileName, $"We will be executing rules on {fullEntityStateObj.Households.Count} households using {subBatches.Count} sub-batched execution requests of {config.ItemsPerSubBatch} households running on {config.MaxParallelRequests} threads.");

                    // Prepare for execution
                    BatchProcessingRequest output = new BatchProcessingRequest();

                    if (runCount == 1)
                    {
                        //For the warmup, just use a single request, since the purpose is just to compile the RuleApp so we don't hit a Cold Start - amount of content is irrelevant
                        var warmupBatch = new List<Household>
                        {
                            fullEntityStateObj.Households.FirstOrDefault()
                        };
                        Output(logFileName, $"Starting warmup...");
                        //Warm Up with 3 synchronus executions
                        var warmup1 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output, logFileName);
                        var warmupSeconds = Math.Round(((DateTime.UtcNow - warmup1).TotalSeconds), 3);
                        Output(logFileName, $"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        var warmup2 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output, logFileName);
                        warmupSeconds = Math.Round(((DateTime.UtcNow - warmup2).TotalSeconds), 3);
                        Output(logFileName, $"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        var warmup3 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output, logFileName);
                        warmupSeconds = Math.Round(((DateTime.UtcNow - warmup3).TotalSeconds), 3);
                        Output(logFileName, $"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        Output(logFileName, $"Warm up complete.");
                        output.Reset();
                    }
                    
                    Output(logFileName, $"Starting executions...");
                    _executionId++; // skip ID 0 so real executions start at ID 1
                    var tasks = new List<Task<string>>();

                    // Load Threads
                    while (tasks.Count < config.MaxParallelRequests && subBatches.Any())
                    {
                        try { tasks.Add(ExecuteSubBatch(subBatches.Dequeue(), config, output, logFileName)); }
                        catch (Exception ex) { Output(logFileName, "Task add fail." + ex.Message); }
                    }
                    var taskStartTime = DateTime.UtcNow;
                    // Continue running tests until we've processed all data
                    while (subBatches.Any())
                    {
                        await Task.WhenAny(tasks);
                        tasks.RemoveAll(t => t.Status == TaskStatus.RanToCompletion);
                        while (tasks.Count < config.MaxParallelRequests && subBatches.Any())
                        {
                            tasks.Add(ExecuteSubBatch(subBatches.Dequeue(), config, output, logFileName));
                        }
                    }

                    Output(logFileName, $"Executions completed in {Math.Round(((DateTime.UtcNow - taskStartTime).TotalMinutes), 3)} minutes.");

                    // Wait until all pending executions have completed
                    await Task.WhenAll(tasks);

                    var startTimeOutPutMapping = DateTime.UtcNow;
                    LowIncomeOutput lowIncomeOutput = new LowIncomeOutput();

                    lowIncomeOutput.HouseholdOutput = new HouseholdOutput() { HouseholdOutputAttributes = new List<HouseholdOutputAttributes>() };
                    lowIncomeOutput.PersonOutput = new PersonOutput() { PersonOutputAttributes = new List<PersonOutputAttributes>() };
                    MapLowIncomeOutputData(output, lowIncomeOutput);
                    Output(logFileName, $"Output mapping complete for run {runCount} in {Math.Round(((DateTime.UtcNow - startTimeOutPutMapping).TotalSeconds), 3)} seconds.");

                    var startTimeDBLoad = DateTime.UtcNow;
                    await BulkUploadLowIncomeOutputData(config, logFileName, connString, lowIncomeOutput);
                    Output(logFileName, $"Output data loaded back to DB successfully in {Math.Round(((DateTime.UtcNow - startTimeDBLoad).TotalSeconds), 3)} seconds.");

                    // Final wrap up 

                    Output(logFileName, $"Run {runCount} completed in {Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 3)} minutes. Total time elapsed: {Math.Round((DateTime.UtcNow - startTimeOverall).TotalMinutes, 3)} minutes.");
                    Output(logFileName, "");
                    runCount++;
                }
            }
            catch (Exception ex)
            {
                Output(logFileName, "An error occured while we were running the test." + ex.Message);
            }
        }
        public LowIncomeOutput MapLowIncomeOutputData(BatchProcessingRequest output, LowIncomeOutput lowIncomeOutput)
        {
            try
            {
                foreach (var household in output.Households)
                {
                    HouseholdOutputAttributes householdOutputAttributes = new HouseholdOutputAttributes()
                    {
                        I_HH_ID = household.I_HH_ID,
                        LAAG_INK = household.HouseholdOutputAttributes.LAAG_INK,
                        ARMLAG = household.HouseholdOutputAttributes.ARMLAG,
                        ARMLAGKL1 = household.HouseholdOutputAttributes.ARMLAGKL1,
                        BMNORMH = household.HouseholdOutputAttributes.BMNORMH,
                        ARMSOC = household.HouseholdOutputAttributes.ARMSOC,
                        ARMSOCKL1 = household.HouseholdOutputAttributes.ARMSOCKL1
                    };
                    foreach (var persons in household.Persons)
                    {
                        PersonOutputAttributes personOutputAttributes = new PersonOutputAttributes()
                        {
                            I_SOFINR = persons.I_SOFINR,
                            BM_GROEP = persons.PersonOutputAttributes.BM_GROEP,
                            BMNORM = persons.PersonOutputAttributes.BMNORM
                        };
                        lowIncomeOutput.PersonOutput.PersonOutputAttributes.Add(personOutputAttributes);
                    }
                    lowIncomeOutput.HouseholdOutput.HouseholdOutputAttributes.Add(householdOutputAttributes);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error mapping output: " + ex.Message);
            }
            return lowIncomeOutput;
        }

        public async Task BulkUploadLowIncomeOutputData(OrchestrationToolConfig config, string logFileName, string connString, LowIncomeOutput lowIncomeOutput)
        {
            try
            {
                DataTable householdDT = ConvertToDataTable(lowIncomeOutput.HouseholdOutput.HouseholdOutputAttributes);
                DataTable personDT = ConvertToDataTable(lowIncomeOutput.PersonOutput.PersonOutputAttributes);
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    connection.Open();
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.DestinationTableName = config.LowIncomeSQLTables.HouseholdOutputTable;
                        bulkCopy.BatchSize = householdDT.Rows.Count;
                        await bulkCopy.WriteToServerAsync(householdDT);
                        //bulkCopy.Close();
                    }
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.DestinationTableName = config.LowIncomeSQLTables.PersonOutputTable;
                        bulkCopy.BatchSize = personDT.Rows.Count;
                        await bulkCopy.WriteToServerAsync(personDT);
                        //bulkCopy.Close();
                    }
                }
            }
            catch (Exception ex) { Output(logFileName, "An error occured while we were running SQL BulkUpload." + ex.Message); }
        }

        public async Task<string> ExecuteSubBatch(List<Household> thisBatch, OrchestrationToolConfig config, BatchProcessingRequest output, string logFileName)
        {
            var thisExecutionId = _executionId++;
            try
            {
                BatchProcessingRequest thisRequest = new BatchProcessingRequest() { Jaar = config.Jaar, Households = thisBatch };
                var result = await RexClient.Apply(thisRequest, config.RuleAppName, config.EntityName);
                if (result.Households != null) { lock (output.Lock) { output.Households.AddRange(result.Households); } }

            }
            catch (Exception ex)
            {
                Output(logFileName, $"Error processing sub-batch {thisExecutionId} " + ex.Message);
            }
            return "";
        }
        //private async Task<string> ExecuteSubBatchSDK(List<Household> thisBatch, OrchestrationToolConfig config, BatchProcessingRequest output, string logFileName)
        //{
        //    var thisExecutionId = _executionId++;
        //    try
        //    {
        //        BatchProcessingRequest thisRequest = new BatchProcessingRequest() { Jaar = config.Jaar, Households = thisBatch };

        //        var result = await ApplyViaIrSDK(thisRequest, config.EntityName);
        //        if (result.Households != null) { lock (output.Lock) { output.Households.AddRange(result.Households); } }

        //    }
        //    catch (Exception ex)
        //    {//after {(DateTime.UtcNow - taskStartTime).TotalMilliseconds}ms: 
        //        Output(logFileName, $"Error processing sub-batch {thisExecutionId} " + ex.Message);
        //    }
        //    return "";
        //}

        //public static Task<T> ApplyViaIrSDK<T>(T initialEntityState, string entityName) where T : new()
        //{
        //    RuleApplicationReference ruleAppRef = new FileSystemRuleApplicationReference(@"C:\CODE\CBS\RuleApp\CBS_Low_Income.ruleappx");
        //    var session = new RuleSession(ruleAppRef);
        //    Entity entity = session.CreateEntity(entityName, initialEntityState);
        //    session.ApplyRules();
        //    return initialEntityState;
        //}

        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public List<T> ConvertToList<T>(DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>()
                    .Select(c => c.ColumnName)
                    .ToList();
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name))
                    {
                        PropertyInfo pI = objT.GetType().GetProperty(pro.Name);
                        pro.SetValue(objT, row[pro.Name] == DBNull.Value ? null : Convert.ChangeType(row[pro.Name], pI.PropertyType));
                    }
                }
                return objT;
            }).ToList();
        }
        public static void Output(string fileName, string log)
        {
            Console.WriteLine(log);
            File.AppendAllText(fileName, log + Environment.NewLine);
        }
        //static async Task<StringBuilder> WriteCharacters(StringBuilder stringToWrite, string log)
        //{
        //    //StringBuilder stringToWrite = new StringBuilder("Characters in StringBuilder");
        //    //stringToWrite.AppendLine();

        //    using (StringWriter writer = new StringWriter(stringToWrite))
        //    {
        //        await writer.WriteLineAsync("and add characters through StringWriter");
        //        Console.WriteLine(stringToWrite.ToString());
        //    }

        //    return stringToWrite;
        //}
    }
}
