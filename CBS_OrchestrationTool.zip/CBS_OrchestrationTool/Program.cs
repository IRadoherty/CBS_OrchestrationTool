﻿using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;
using System.Reflection;

namespace CBS_LoadTest_NF
{
    class Program
    {
        private static int _executionId = 0;
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder().AddJsonFile($"appSettings.json", true, true);
            var builtConfig = builder.Build();
            var config = builtConfig.Get<OrchestrationToolConfig>();
            RexClient._config = config.ExecutionService;
            var Program = new Program();
            Program.MainAsync(config);
            Console.ReadLine();
        }

        private async void MainAsync(OrchestrationToolConfig config)
        {
            var startTimeOverall = DateTime.UtcNow;
            Console.WriteLine($"Beginning main run at {DateTime.Now}");
            int runCount = 1; // set initial run count
            try
            {
                string connString = @"Data Source=" + config.Datasource + ";Initial Catalog=" + config.Database + ";Persist Security Info=True;User ID=" + config.Username + ";Password=" + config.Password + ";MultipleActiveResultSets = true";
                bool runOnce = true;
                int rowStart = config.HouseHoldCountStart; // HouseHold count start
                int rowPullCount = config.HouseHoldCountEnd; // HouseHold count end
                int rowEnd = rowPullCount;
                int householdTotal = 0;
                var subBatchesDB = new Queue<List<Household>>();
                if (config.DeleteOutputTables == true)
                {
                    string deleteHouseHoldOutput = $"DELETE FROM {config.Database}.{config.LowIncomeSQLTables.HouseholdOutputTable}";
                    string deletePersonsOutput = $"DELETE FROM {config.Database}.{config.LowIncomeSQLTables.PersonOutputTable}";
                    using (SqlConnection connection = new SqlConnection(connString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(deleteHouseHoldOutput, connection))
                        using (SqlDataReader reader = command.ExecuteReader()) { }
                        using (SqlCommand command = new SqlCommand(deletePersonsOutput, connection))
                        using (SqlDataReader reader = command.ExecuteReader()) { }
                        //using (SqlCommand cmd = new SqlCommand(queryMaxHouseHolds, connection))
                        //{ MaxHouseholdsQ = (Int32)cmd.ExecuteScalar(); }
                        //using (SqlCommand cmd = new SqlCommand(queryMaxPersons, connection))
                        //{ MaxPersonsQ = (Int32)cmd.ExecuteScalar(); }
                    }
                }

                bool cont = true; // Sets warm up calls to run only once for irServer
                while (cont == true)
                {
                    var startTime = DateTime.UtcNow;
                    BatchProcessingRequest fullEntityStateObj = new BatchProcessingRequest()
                    {
                        Households = new List<Household>()
                    };
                    Console.WriteLine($"Connecting to database and pulling data for run {runCount} for households between {rowStart} and {rowEnd}.");
                    string queryString = $"SELECT {config.LowIncomeSQLTables.PersonTable}.I_SOFINR, {config.LowIncomeSQLTables.LinkTable}.PAAR_NR, {config.LowIncomeSQLTables.PersonTable}.WEKEN, {config.LowIncomeSQLTables.PersonTable}.BRUTOGRONDBOX3, {config.LowIncomeSQLTables.PersonTable}.YVBD3610, {config.LowIncomeSQLTables.PersonTable}.T07_OGO, {config.LowIncomeSQLTables.PersonTable}.GEBJAAR, {config.LowIncomeSQLTables.PersonTable}.WSFRECHT, {config.LowIncomeSQLTables.PersonTable}.YBTL7370, {config.LowIncomeSQLTables.PersonTable}.YBTS7380, {config.LowIncomeSQLTables.PersonTable}.PERSINK, {config.LowIncomeSQLTables.PersonTable}.T6330STU, {config.LowIncomeSQLTables.PersonTable}.T6320KB, {config.LowIncomeSQLTables.PersonTable}.T6325KGB, {config.LowIncomeSQLTables.PersonTable}.PH865ZFW, {config.LowIncomeSQLTables.PersonTable}.PH868ZTS, {config.LowIncomeSQLTables.PersonTable}.YCGW5246, {config.LowIncomeSQLTables.PersonTable}.YCGW6346, {config.LowIncomeSQLTables.PersonTable}.YKKT6348, {config.LowIncomeSQLTables.PersonTable}.GEBMAAND, {config.LowIncomeSQLTables.PersonTable}.SECJ, {config.LowIncomeSQLTables.PersonTable}.POSHHK, {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID, {config.LowIncomeSQLTables.HouseholdTable}.BESTINKH, {config.LowIncomeSQLTables.HouseholdTable}.EQUI, {config.LowIncomeSQLTables.HouseholdTable}.POP, {config.LowIncomeSQLTables.HouseholdTable}.SAMHH FROM {config.LowIncomeSQLTables.HouseholdTable} INNER JOIN {config.LowIncomeSQLTables.LinkTable} ON {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID = {config.LowIncomeSQLTables.LinkTable}.I_HH_ID INNER JOIN {config.LowIncomeSQLTables.PersonTable} ON {config.LowIncomeSQLTables.LinkTable}.I_SOFINR = {config.LowIncomeSQLTables.PersonTable}.I_SOFINR where {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID BETWEEN {rowStart} and {rowEnd} ORDER by {config.LowIncomeSQLTables.HouseholdTable}.I_HH_ID ASC;";
                    // Populate dataTable
                    int datatableCount = 0;
                    var startTimeSQLPull = DateTime.UtcNow;
                    using (SqlConnection connection = new SqlConnection(connString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(queryString, connection))
                        {
                            //command.CommandTimeout = 10 * 60;
                            SqlDataReader reader = command.ExecuteReader();
                            var dataTable = new DataTable();
                            dataTable.Load(reader);
                            Console.WriteLine($"SQL pull completed in {Math.Round((DateTime.UtcNow - startTimeSQLPull).TotalMinutes, 3)} minutes.");
                            var startTimeDBMapping = DateTime.UtcNow;
                            datatableCount = dataTable.Rows.Count;
                            //IList<Household> test = ConvertToList<Household>(dataTable);
                            Household household = null;
                            Person person = null;
                            bool pcont = true;

                            for (int g = 0; g < datatableCount; g++)
                            {
                                household = new Household
                                {
                                    I_HH_ID = dataTable.Rows[g].Field<int?>("I_HH_ID"),
                                    BESTINKH = dataTable.Rows[g].Field<decimal?>("BESTINKH"),
                                    EQUI = dataTable.Rows[g].Field<decimal?>("EQUI"),
                                    POP = dataTable.Rows[g].Field<int?>("POP"),
                                    SAMHH = dataTable.Rows[g].Field<int?>("SAMHH"),
                                    Persons = new List<Person>()
                                };
                                while (pcont == true)
                                {
                                    person = new Person
                                    {
                                        I_SOFINR = dataTable.Rows[g].Field<string>("I_SOFINR"),
                                        POSHHK = dataTable.Rows[g].Field<int?>("POSHHK"),
                                        WEKEN = dataTable.Rows[g].Field<int?>("WEKEN"),
                                        BRUTOGRONDBOX3 = dataTable.Rows[g].Field<decimal?>("BRUTOGRONDBOX3"),
                                        YVBD3610 = dataTable.Rows[g].Field<decimal?>("YVBD3610"),
                                        T07_OGO = dataTable.Rows[g].Field<decimal?>("T07_OGO"),
                                        GEBJAAR = dataTable.Rows[g].Field<int?>("GEBJAAR"),
                                        WSFRECHT = dataTable.Rows[g].Field<string>("WSFRECHT"),
                                        YBTL7370 = dataTable.Rows[g].Field<decimal?>("YBTL7370"),
                                        YBTS7380 = dataTable.Rows[g].Field<decimal?>("YBTS7380"),
                                        PERSINK = dataTable.Rows[g].Field<decimal?>("PERSINK"),
                                        T6330STU = dataTable.Rows[g].Field<decimal?>("T6330STU"),
                                        T6320KB = dataTable.Rows[g].Field<decimal?>("T6320KB"),
                                        T6325KGB = dataTable.Rows[g].Field<decimal?>("T6325KGB"),
                                        PH865ZFW = dataTable.Rows[g].Field<decimal?>("PH865ZFW"),
                                        PH868ZTS = dataTable.Rows[g].Field<decimal?>("PH868ZTS"),
                                        YCGW5246 = dataTable.Rows[g].Field<decimal?>("YCGW5246"),
                                        YCGW6346 = dataTable.Rows[g].Field<decimal?>("YCGW6346"),
                                        YKKT6348 = dataTable.Rows[g].Field<decimal?>("YKKT6348"),
                                        GEBMAAND = dataTable.Rows[g].Field<int?>("GEBMAAND"),
                                        SECJ = dataTable.Rows[g].Field<int?>("SECJ"),
                                        PAARCOD = dataTable.Rows[g].Field<int?>("PAAR_NR")
                                    };
                                    household.Persons.Add(person);
                                    if (g != datatableCount - 1)
                                    {
                                        int? I_HH_ID2 = dataTable.Rows[g + 1].Field<int?>("I_HH_ID");
                                        if (household.I_HH_ID == I_HH_ID2) { g++; }
                                        else { break; }
                                    }
                                    else { break; }
                                };
                                fullEntityStateObj.Households.Add(household);
                            }
                            Console.WriteLine($"Mapping complete for {datatableCount} persons/rows in {Math.Round((DateTime.UtcNow - startTimeDBMapping).TotalMinutes, 3)} minutes.");
                        }
                    }
                    rowStart = rowEnd + 1;
                    rowEnd += rowPullCount;
                    householdTotal += fullEntityStateObj.Households.Count;
                    string fullEntityState = JsonConvert.SerializeObject(fullEntityStateObj);

                    if (!fullEntityStateObj.Households.Any())
                    {
                        //Console.WriteLine("No HouseHolds to process in the source data file. Press enter to exit."); //{personTotal}
                        Console.WriteLine($"{householdTotal} households persons were processed in {Math.Round(((DateTime.UtcNow - startTimeOverall).TotalMinutes), 3)} minutes at {DateTime.Now}");
                        cont = false;
                        return;
                    }
                    // Load all the sub-batches into the queue
                    var subBatches = new Queue<List<Household>>();
                    var subBatch = new List<Household>();
                    foreach (var item in fullEntityStateObj.Households)
                    {
                        subBatch.Add(item);
                        if (subBatch.Count >= config.ItemsPerSubBatch)
                        {
                            subBatches.Enqueue(subBatch);
                            subBatch = new List<Household>();
                        }
                    }
                    if (subBatch.Any())
                        subBatches.Enqueue(subBatch);
                    //Console.WriteLine($"We will be executing rules on {fullEntityStateObj.Households.Count} households using {subBatches.Count} sub-batched execution requests of {config.ItemsPerSubBatch} households running on {config.MaxParallelRequests} threads.");

                    // Prepare for execution
                    BatchProcessingRequest output = new BatchProcessingRequest();

                    if (runOnce == true)
                    {
                        //For the warmup, just use a single request, since the purpose is just to compile the RuleApp so we don't hit a Cold Start - amount of content is irrelevant
                        var warmupBatch = new List<Household>
                        {
                            fullEntityStateObj.Households.FirstOrDefault()
                        };
                        //Console.WriteLine($"Starting warmup...");
                        // Warm Up with 3 synchronus executions
                        //var warmup1 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output);
                        //var warmupSeconds = Math.Round(((DateTime.UtcNow - warmup1).TotalSeconds), 3);
                        //Console.WriteLine($"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        //var warmup2 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output);
                        //warmupSeconds = Math.Round(((DateTime.UtcNow - warmup2).TotalSeconds), 3);
                        //Console.WriteLine($"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        //var warmup/3 = DateTime.UtcNow;
                        await ExecuteSubBatch(warmupBatch, config, output);
                        //warmupSeconds = Math.Round(((DateTime.UtcNow - warmup3).TotalSeconds), 3);
                        //Console.WriteLine($"Sub-batch {_executionId} execution completed in {warmupSeconds} seconds.");
                        //Console.WriteLine($"Warm up complete.");
                        output.Reset();
                    }

                    Console.WriteLine($"Starting executions...");
                    _executionId++; // skip ID 0 so real executions start at ID 1
                    var tasks = new List<Task<string>>();

                    // Load Threads
                    while (tasks.Count < config.MaxParallelRequests && subBatches.Any())
                    {
                        try { tasks.Add(ExecuteSubBatch(subBatches.Dequeue(), config, output)); }
                        catch (Exception ex) { Console.WriteLine("Task add fail." + ex.Message); }
                    }
                    var taskStartTime = DateTime.UtcNow;
                    // Continue running tests until we've processed all data
                    while (subBatches.Any())
                    {
                        await Task.WhenAny(tasks);
                        tasks.RemoveAll(t => t.Status == TaskStatus.RanToCompletion);
                        while (tasks.Count < config.MaxParallelRequests && subBatches.Any())
                        {
                            tasks.Add(ExecuteSubBatch(subBatches.Dequeue(), config, output));
                        }
                    }

                    Console.WriteLine($"Executions completed in {Math.Round(((DateTime.UtcNow - taskStartTime).TotalMinutes), 3)} minutes.");

                    // Wait until all pending executions have completed
                    await Task.WhenAll(tasks);
                    var startTimeOutPutMapping = DateTime.UtcNow;
                    HouseholdOutput householdOutput = new HouseholdOutput() { HouseholdOutputAttributes = new List<HouseholdOutputAttributes>() };
                    PersonOutput personOutput = new PersonOutput() { PersonOutputAttributes = new List<PersonOutputAttributes>() };
                    try
                    {
                        foreach (var household in output.Households)
                        {
                            HouseholdOutputAttributes householdOutputAttributes = new HouseholdOutputAttributes()
                            {
                                I_HH_ID = household.I_HH_ID,
                                LAAG_INK = household.HouseholdOutputAttributes.LAAG_INK,
                                ARMLAG = household.HouseholdOutputAttributes.ARMLAG,
                                ARMLAGKL1 = household.HouseholdOutputAttributes.ARMLAGKL1,
                                BMNORMH = household.HouseholdOutputAttributes.BMNORMH,
                                ARMSOC = household.HouseholdOutputAttributes.ARMSOC,
                                ARMSOCKL1 = household.HouseholdOutputAttributes.ARMSOCKL1
                            };
                            foreach (var persons in household.Persons)
                            {
                                PersonOutputAttributes personOutputAttributes = new PersonOutputAttributes()
                                {
                                    I_SOFINR = persons.I_SOFINR,
                                    BM_GROEP = persons.PersonOutputAttributes.BM_GROEP,
                                    BMNORM = persons.PersonOutputAttributes.BMNORM
                                };
                                personOutput.PersonOutputAttributes.Add(personOutputAttributes);
                            }
                            householdOutput.HouseholdOutputAttributes.Add(householdOutputAttributes);
                        }
                    }
                    catch (Exception ex) { throw new Exception("Error mapping output: " + ex.Message); }
                    Console.WriteLine($"Output mapping complete for run {runCount} in {Math.Round(((DateTime.UtcNow - startTimeOutPutMapping).TotalSeconds), 3)} seconds.");

                    var startTimeDBLoad = DateTime.UtcNow;
                    try
                    {
                        DataTable householdDT = ConvertToDataTable(householdOutput.HouseholdOutputAttributes);
                        DataTable personDT = ConvertToDataTable(personOutput.PersonOutputAttributes);
                        using (SqlConnection connection = new SqlConnection(connString))
                        {
                            connection.Open();
                            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                            {
                                bulkCopy.DestinationTableName = config.LowIncomeSQLTables.HouseholdOutputTable;
                                bulkCopy.BatchSize = householdDT.Rows.Count;
                                bulkCopy.WriteToServer(householdDT);     
                                bulkCopy.Close();
                            }
                            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                            {
                                bulkCopy.DestinationTableName = config.LowIncomeSQLTables.PersonOutputTable;
                                bulkCopy.BatchSize = personDT.Rows.Count;
                                bulkCopy.WriteToServer(personDT);
                                bulkCopy.Close();
                            }
                        }
                    }
                    catch (Exception ex) { Console.WriteLine("An error occured while we were running SQL BulkUpload." + ex.Message); }
                    Console.WriteLine($"Output data loaded back to DB successfully in {Math.Round(((DateTime.UtcNow - startTimeDBLoad).TotalMinutes), 3)} minutes.");
                    Console.WriteLine($"Run {runCount} completed in {Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 3)} minutes.");
                    Console.WriteLine();
                    runCount++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occured while we were running the test." + ex.Message);
            }
            Console.WriteLine();
        }

        private async Task<string> ExecuteSubBatch(List<Household> thisBatch, OrchestrationToolConfig config, BatchProcessingRequest output)
        {
            var thisExecutionId = _executionId++;
            try
            {
                BatchProcessingRequest thisRequest = new BatchProcessingRequest() { Jaar = config.Jaar, Households = thisBatch };
                var result = await RexClient.Apply(thisRequest, config.RuleAppName, config.EntityName);
                if (result.Households != null) { lock (output.Lock) { output.Households.AddRange(result.Households); } }
                //var executionSeconds = Math.Round(((DateTime.UtcNow - taskStartTime).TotalSeconds), 3);
                //Console.WriteLine($"Sub-batch {thisExecutionId} execution completed in {executionSeconds} seconds.");
            }
            catch (Exception ex)
            {//after {(DateTime.UtcNow - taskStartTime).TotalMilliseconds}ms: 
                Console.WriteLine($"Error processing sub-batch {thisExecutionId} " + ex.Message);
            }

            return "";
        }

        //private static async Task<string> Post(string targetUrl, string stringContent)
        //{
        //    StringContent content = new StringContent(stringContent, Encoding.UTF8, "application/json");
        //    string responseString = "";
        //    using (HttpClient client = new HttpClient())
        //    {
        //        client.DefaultRequestHeaders.Add("Accept", "application/json");
        //        //client.DefaultRequestHeaders.Add("Authorization", _config.AuthHeader);
        //        client.Timeout = TimeSpan.FromMinutes(5); // Defaults to 100 seconds
        //        HttpResponseMessage response = await client.PostAsync(targetUrl, content);
        //        if (response.StatusCode != System.Net.HttpStatusCode.OK)
        //        {
        //            // So we can identify other error codes that we can retry (like 502), log out what happened
        //            var errorInfo = await response.Content.ReadAsStringAsync();
        //            var errorMessage = errorInfo.Split(new string[] { "<Message>" }, StringSplitOptions.RemoveEmptyEntries).Last().Split(new string[] { "</Message>" }, StringSplitOptions.RemoveEmptyEntries)[0];
        //            Console.WriteLine($"Received unexpected {response.StatusCode} response from server, this execution request has most likely failed: " + errorMessage);
        //        }
        //        if (response != null)
        //        {
        //            responseString = await response.Content.ReadAsStringAsync();
        //        }
        //    }
        //    return responseString;
        //}
        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public List<T> ConvertToList<T>(DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>()
                    .Select(c => c.ColumnName)
                    .ToList();
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name))
                    {
                        PropertyInfo pI = objT.GetType().GetProperty(pro.Name);
                        pro.SetValue(objT, row[pro.Name] == DBNull.Value ? null : Convert.ChangeType(row[pro.Name], pI.PropertyType));
                    }
                }
                return objT;
            }).ToList();
        }
    }
}
