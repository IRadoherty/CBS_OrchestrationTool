﻿using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CBS_LoadTest_NF
{

    public class RexClient
    {
        internal static RESConfig _config;
        static RexClient()
        {
            System.Net.ServicePointManager.DefaultConnectionLimit = 1000;
        }
        public static async Task<T> Apply<T>(T initialEntityState, string ruleAppName, string entityName) where T : new()
        {
            string entityState = JsonConvert.SerializeObject(initialEntityState);
            EntityStateRuleRequest request = new ApplyRulesRequest()
            {
                RuleApp = new Ruleapp()
                {
                    RepositoryRuleAppRevisionSpec = new Repositoryruleapprevisionspec()
                    {
                        RuleApplicationName = ruleAppName
                    },
                    RepositoryServiceUri = _config.CatalogUrl,
                    UserName = _config.CatalogUser,
                    Password = _config.CatalogPassword
                },
                EntityName = entityName,
                EntityState = entityState
            };
            string result = null;
            try
            {
                string stringContent = JsonConvert.SerializeObject(request);
                result = await Post(_config.ResUrl + "/HttpService.svc/" + request.Route, stringContent);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error placing POST request to execution service: " + ex.Message + ".  Response: " + result);
                throw new Exception("Error placing POST request to execution service: " + ex.Message + ".  Response: " + result);
            }

            try
            {
                RuleExecutionResponse responseObject = JsonConvert.DeserializeObject<RuleExecutionResponse>(result);
                string entityStateString = responseObject.EntityState;
       
                T finalEntityState = JsonConvert.DeserializeObject<T>(entityStateString);
                return finalEntityState;
            }
            catch (Exception ex)
            {
                throw new Exception("Error deserializing execution service response: " + ex.Message + ".  Response: " + result);
            }
        }

        private static async Task<string> Post(string targetUrl, string stringContent)
        {
            StringContent content = new StringContent(stringContent, Encoding.UTF8, "application/json");
            string responseString = "";
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    //client.DefaultRequestHeaders.Add("Authorization", _config.AuthHeader);
                    client.Timeout = TimeSpan.FromMinutes(5); // Defaults to 100 seconds
                    HttpResponseMessage response = await client.PostAsync(targetUrl, content);
                    if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    // So we can identify other error codes that we can retry (like 502), log out what happened
                    var errorInfo = await response.Content.ReadAsStringAsync();
                    var errorMessage = errorInfo.Split(new string[] { "<Message>" }, StringSplitOptions.RemoveEmptyEntries).Last().Split(new string[] { "</Message>" }, StringSplitOptions.RemoveEmptyEntries)[0];
                    Console.WriteLine($"Received unexpected {response.StatusCode} response from server, this execution request has most likely failed: " + errorMessage);
                }

                if (response != null)
                {
                    responseString = await response.Content.ReadAsStringAsync();
                }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"HTTP ERROR:" + ex.Message);
                }

                //if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                //{
                //    Console.WriteLine("Received 401 Unauthorized from execution service");
                //    response = null; // Don't need to log full response, basic logging is sufficient for this error respose
                //}
                //else if (response.StatusCode == System.Net.HttpStatusCode.BadGateway)
                //{
                //    Console.WriteLine("Received 502 BadGateway response.  Assuming scale event on execution service, resubmitting request for //one retry");
                //    response = await client.PostAsync(targetUrl, content);
                //}
                //else if (response.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
               // {
               //     Console.WriteLine("Received 503 ServiceUnavailable response.  Assuming scale event on execution service, resubmitting //request for one retry");
                //    response = await client.PostAsync(targetUrl, content);
               // }

                
            }
            return responseString;
        }
    }
}
